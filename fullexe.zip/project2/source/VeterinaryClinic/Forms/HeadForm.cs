﻿using System.Windows.Forms;

namespace VeterinaryClinic.Forms
{
    internal partial class HeadForm : Form
    {
        internal HeadForm()
        {
            InitializeComponent();
        }
    }
}
